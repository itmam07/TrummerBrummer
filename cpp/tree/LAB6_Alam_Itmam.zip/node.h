/*
author: Itmam ALam
file: node.h
class: node
*/

//--------includes-------
#include <iostream>
using namespace std;

//--------class----------
class node {
private:
    string value;
    node* left;
    node* right;
public:
    node(string value);
    string getValue();
    node* getLeft();
    node* getRight();
    void setLeft(node* node);
    void setRight(node* node);
    ~node();
};
