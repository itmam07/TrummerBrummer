/*
author: Itmam ALam
file: node.cpp
class: node
*/

//--------includes-------
#include "node.h"

//---------methods-------
node::node(string value) {
    this->value = value;
    this->left = nullptr;
    this->right = nullptr;
}

string node::getValue() {
    return value;
}

node* node::getLeft() {
    return left;
}

node* node::getRight() {
    return right;
}

void node::setLeft(node* node) {
    this->left = node;
}

void node::setRight(node* node) {
    this->right = node;
}

node::~node() {
    cout << "- deleting " << getValue() << endl;
}
