/*
author: Itmam ALam
file: treedemo.cpp
class: binary tree test file
*/

//--------includes-------
#include <iostream>
using namespace std;
#include "tree.h"

//--------main-----------
int main() { 
    tree t;

    cout << "\n----adding" << endl;
    t.add_iterative("Hello"); 
    t.add_iterative("World"); 
    t.add_iterative("How"); 
    t.add_recursive("Are"); 
    t.add_recursive("You");
    cout << "----adding done\n" << endl;
    
    cout << "----printing" << endl;
    t.print_recursive();
    cout << "----printing done\n" << endl;

    cout << "----printing reverse" << endl;
    t.print_reverse_recursive();
    cout << "----printing reverse done\n" << endl;

    cout << "----searching" << endl;
    cout << t.search_iterative("How") << endl;
    cout << t.search_recursive("How") << endl;
    
    cout << t.search_iterative("How2") << endl;
    cout << t.search_recursive("How2") << endl;
    cout << "----searching done\n" << endl;
}
