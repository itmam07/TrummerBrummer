/*
author: Itmam ALam
file: tree.cpp
class: tree
*/

//--------includes-------
#include <cstring>
#include "tree.h"

//---------methods-------
tree::tree() {
    root = nullptr;
}

void tree::add_iterative(string value) {
    node* newNode = new node(value);                        // erstelle neuen node
    if (root == nullptr) {                                  // wenn tree leer setze neuen node
        root = newNode;
        cout << "- adding " << value << endl;
        return;
    }
    node* current = root;                                   // aktuelle node
    while (true) {
        if (current->getValue().compare(value) < 0) {       // wenn das value größer ist als das aktuelle node, geh nach links
            if (current->getLeft() == nullptr) {            // wenn es keinen nachfolger gibt füge ein
                current->setLeft(newNode);
                cout << "- adding " << value << endl;
                return;
            }
            current = current->getLeft();                   // wenn es einen nachfolger gibt, geh zum nächsten node
        }
        else {                                              // wenn das value kleiner ist als das aktuelle node, geh nach rechts
            if (current->getRight() == nullptr) {           // wenn es keinen nachfolger gibt füge ein
                current->setRight(newNode);
                cout << "- adding " << value << endl;
                return;
            }
            current = current->getRight();                  // wenn es einen nachfolger gibt, geh zum nächsten node
        }
    }
}

void tree::add_recursive(string value) {
    root = add_recursive(root, value);
    cout << "- adding " << value << endl;
}

node* tree::add_recursive(node* current, string value) {
    if (current == nullptr) {                                        // wenn tree leer setze neuen node
        return new node(value);
    }
    if (current->getValue().compare(value) < 0) {                    // wenn das value größer ist als das aktuelle node, geh nach links
        current->setLeft(add_recursive(current->getLeft(), value));
    }
    else {                                                           // else geh nach rechts
        current->setRight(add_recursive(current->getRight(), value));
    }
    return current;                                                  // return aktuellen node
}

string tree::search_iterative(string value) {
    node* current = root;
    while (current != nullptr) {
        if (current->getValue() == value) {
            return current->getValue();
        } else if (current->getValue().compare(value) < 0) {
            current = current->getLeft();
        } else {
            current = current->getRight();
        }
    }
    return "Element does not exist!";
}

string tree::search_recursive(string value) {
    return search_recursive(root, value);
}

string tree::search_recursive(node* current, string value) {
    if (current == nullptr) {                               // wenn baum leer oder ende des baumes erreicht dann fehler
        return "Element does not exist!";
    }
    if (current->getValue() == value) {                     // wenn aktueller node == gesuchter node return
        return current->getValue();
    }
    if (current->getValue().compare(value) < 0) {           // checken ob gesuchter wert größer ist als der aktuelle, geh nach links
        return search_recursive(current->getLeft(), value);
    }
    else {                                                  // else geh nach rechts
        return search_recursive(current->getRight(), value);
    }
}

void tree::print_recursive() {
    print_recursive(root);                          // rufe die hilfsmethode auf
}

void tree::print_recursive(node* next) {
    if (next == nullptr) {                          // checken ob baum leer
        return;
    }
    print_recursive(next->getLeft());               // als erstes nach links gehen
    cout << next->getValue() << endl;               // ausgeben
    print_recursive(next->getRight());              // dann nach rechts gehen
}

void tree::print_reverse_recursive() {
    print_reverse_recursive(root);                  // rufe die hilfsmethode auf
}

void tree::print_reverse_recursive(node* next) {
    if (next == nullptr) {                          // cheacken ob baum leer ist
        return;
    }
    print_reverse_recursive(next->getRight());      // als erstes rechts gehen
    cout << next->getValue() << endl;               // ausgeben
    print_reverse_recursive(next->getLeft());       // dann nach links gehen
}

void tree::destroyTree(node* current) {
	if (current == nullptr) {
        return;
    }
    destroyTree(current->getLeft());
    destroyTree(current->getRight());
    delete current;
}

tree::~tree() {
    destroyTree(root);          // destroy funktion aufrufen
    root = nullptr;         // root auf null setzen
}
