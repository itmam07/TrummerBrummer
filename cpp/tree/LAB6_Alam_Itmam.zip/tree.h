/*
author: Itmam ALam
file: tree.h
class: tree
*/

//--------includes-------
#include "node.h"

//--------class----------
class tree {
    private:
        node* root;
        node* add_recursive(node* current, string value);       // helper method
        string search_recursive(node* current, string value);   // helper method
        void print_recursive(node* next);                       // helper method
        void print_reverse_recursive(node* next);               // helper method

    public:
        tree();
        void add_iterative(string value);
        void add_recursive(string value);
        string search_iterative(string value);
        string search_recursive(string value);
        void print_recursive();
        void print_reverse_recursive();                         
        void destroyTree(node* current);                       
        ~tree();
};
